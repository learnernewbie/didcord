import json
import os
from datetime import datetime

class DataManager:
    def __init__(self):
        self.data = {}
        self.load_data()

    def load_data(self):
        if os.path.exists('data.json'):
            with open('data.json', 'r') as f:
                self.data = json.load(f)

    def save_data(self):
        with open('data.json', 'w') as f:
            json.dump(self.data, f)

    # Economy Methods
    async def get_balance(self, user_id):
        user_id = str(user_id)
        return self.data.get(user_id, {}).get('balance', 0)

    async def add_money(self, user_id, amount):
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {'balance': 0}
        self.data[user_id]['balance'] = max(0, self.data[user_id]['balance'] + amount)
        self.save_data()

    # Bank Methods
    async def get_bank_balance(self, user_id):
        user_id = str(user_id)
        return self.data.get(user_id, {}).get('bank', 0)

    async def add_bank_money(self, user_id, amount):
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {'bank': 0}
        if 'bank' not in self.data[user_id]:
            self.data[user_id]['bank'] = 0
        self.data[user_id]['bank'] = max(0, self.data[user_id]['bank'] + amount)
        self.save_data()

    # Loan Methods
    async def get_loan(self, user_id):
        user_id = str(user_id)
        return self.data.get(user_id, {}).get('loan', 0)

    async def add_loan(self, user_id, amount):
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {'loan': 0}
        if 'loan' not in self.data[user_id]:
            self.data[user_id]['loan'] = 0
        self.data[user_id]['loan'] = max(0, self.data[user_id]['loan'] + amount)
        self.save_data()

    # Level Methods
    async def get_level(self, user_id):
        user_id = str(user_id)
        return self.data.get(user_id, {}).get('level', 0)

    # Moderation Methods
    async def add_warning(self, guild_id, user_id, warning_data):
        guild_id = str(guild_id)
        user_id = str(user_id)
        if guild_id not in self.data:
            self.data[guild_id] = {}
        if 'warnings' not in self.data[guild_id]:
            self.data[guild_id]['warnings'] = {}
        if user_id not in self.data[guild_id]['warnings']:
            self.data[guild_id]['warnings'][user_id] = []

        self.data[guild_id]['warnings'][user_id].append(warning_data)
        self.save_data()

    async def get_warnings(self, guild_id, user_id):
        guild_id = str(guild_id)
        user_id = str(user_id)
        return self.data.get(guild_id, {}).get('warnings', {}).get(user_id, [])

    async def clear_warnings(self, guild_id, user_id):
        guild_id = str(guild_id)
        user_id = str(user_id)
        if guild_id in self.data and 'warnings' in self.data[guild_id]:
            if user_id in self.data[guild_id]['warnings']:
                del self.data[guild_id]['warnings'][user_id]
                self.save_data()

    # Stock Market Methods
    async def get_stocks(self, user_id):
        user_id = str(user_id)
        return self.data.get(user_id, {}).get('stocks', {})

    async def add_stocks(self, user_id, stock, shares):
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {'stocks': {}}
        if 'stocks' not in self.data[user_id]:
            self.data[user_id]['stocks'] = {}
        if stock not in self.data[user_id]['stocks']:
            self.data[user_id]['stocks'][stock] = 0
        self.data[user_id]['stocks'][stock] += shares
        self.save_data()

    # Property Methods
    async def get_properties(self, user_id):
        user_id = str(user_id)
        return self.data.get(user_id, {}).get('properties', {})

    async def add_property(self, user_id, property_type):
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {'properties': {}}
        if 'properties' not in self.data[user_id]:
            self.data[user_id]['properties'] = {}
        if property_type not in self.data[user_id]['properties']:
            self.data[user_id]['properties'][property_type] = 0
        self.data[user_id]['properties'][property_type] += 1
        self.save_data()