async def has_mod_permissions(ctx):
    return ctx.author.guild_permissions.manage_messages
