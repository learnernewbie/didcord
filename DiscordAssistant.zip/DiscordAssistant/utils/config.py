import os

# Bot Configuration
DEFAULT_SERVER_ID = 1334156887012409406
COMMAND_PREFIX = '/'
TEST_CHANNEL_ID = 1337843963713032306

# Event Settings
TICKET_CATEGORY = "TICKETS"
SUPPORT_ROLE_NAME = "Support Team"

def get_token():
    token = os.environ.get('DISCORD_BOT_TOKEN')
    if not token:
        raise ValueError("No Discord bot token found. Please set the DISCORD_BOT_TOKEN environment variable.")
    return token