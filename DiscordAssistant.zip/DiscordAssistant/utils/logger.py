import logging
import datetime

logging.basicConfig(
    filename='bot.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

async def log_command(ctx, command_name):
    logging.info(f"Command: {command_name} | User: {ctx.author} | Channel: {ctx.channel}")
