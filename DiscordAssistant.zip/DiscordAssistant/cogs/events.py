import discord
from discord.ext import commands
from utils.logger import log_command
from datetime import datetime, timedelta
import asyncio
import pytz
from typing import Optional, Dict, Set, Union

class Events(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.events = {}  # {event_id: event_data}
        self.event_counter = 0
        self.reminder_tasks = {}  # {event_id: task}
        self.update_tasks = {}  # {event_id: task}
        bot.loop.create_task(self.start_update_loop())

    @commands.hybrid_command(
        name="createevent",
        description="Create a new event with custom activity groups (max 10) and real-time tracking"
    )
    @discord.app_commands.describe(
        title="Event name (e.g. 'Game Night', 'Movie Watch Party')",
        date="Date in YYYY-MM-DD format (e.g. '2025-02-09')",
        time="Time in HH:MM 24-hour format (e.g. '20:00')",
        timezone="Timezone (default: IST) - e.g. IST, UTC, US/Pacific",
        custom_triggers="Activity groups with emojis (max 10) - Format: '🎮,🎲,🎵' or '🎮🎲🎵'",
        description="Full description of the event"
    )
    async def createevent(
        self,
        ctx: commands.Context,
        title: str,
        date: str,
        time: str,
        timezone: str = "IST",
        custom_triggers: Optional[str] = None,
        *, description: str
    ):
        """Create a new event with custom activity groups and real-time tracking."""
        await log_command(ctx, "createevent")

        try:
            # Convert IST to Asia/Kolkata for proper timezone handling
            if timezone.upper() == "IST":
                timezone = "Asia/Kolkata"

            # Validate timezone
            try:
                tz = pytz.timezone(timezone)
            except pytz.exceptions.UnknownTimeZoneError:
                await ctx.send("Invalid timezone! Please use a valid timezone name (e.g., IST, UTC, US/Pacific)")
                return

            # Parse date and time
            try:
                event_datetime = datetime.strptime(f"{date} {time}", '%Y-%m-%d %H:%M')
                event_datetime = tz.localize(event_datetime)
                utc_time = event_datetime.astimezone(pytz.UTC)
            except ValueError:
                await ctx.send("Invalid date/time format! Use: YYYY-MM-DD HH:MM")
                return

            if utc_time < datetime.now(pytz.UTC):
                await ctx.send("Cannot create events in the past!")
                return

            # Process and validate custom triggers
            custom_trigger_dict = {}
            if custom_triggers:
                # Split triggers by comma if present, otherwise split by character
                triggers = [t.strip() for t in custom_triggers.split(',')] if ',' in custom_triggers else list(custom_triggers.strip())

                # Remove duplicates while preserving order
                triggers = list(dict.fromkeys(triggers))

                # Enforce maximum of 10 triggers
                if len(triggers) > 10:
                    await ctx.send("Maximum 10 activity groups allowed! Please reduce the number of emojis.")
                    return

                # Validate each trigger
                for trigger in triggers:
                    if not trigger:  # Skip empty triggers
                        continue

                    try:
                        # Check for custom Discord emoji format <:name:id>
                        if trigger.startswith('<') and trigger.endswith('>'):
                            try:
                                emoji_id = int(trigger.split(':')[-1][:-1])
                                emoji = self.bot.get_emoji(emoji_id)
                                if emoji is None:
                                    await ctx.send(f"Invalid custom emoji: {trigger}")
                                    return
                            except (ValueError, IndexError):
                                await ctx.send(f"Invalid emoji format: {trigger}")
                                return
                        else:
                            # For Unicode emojis, try to add it as a reaction to validate
                            test_msg = await ctx.send("Testing emoji...")
                            try:
                                await test_msg.add_reaction(trigger)
                            except discord.HTTPException:
                                await ctx.send(f"Invalid emoji: {trigger}")
                                return
                            finally:
                                await test_msg.delete()

                        # If we get here, the emoji is valid
                        custom_trigger_dict[trigger] = set()
                    except Exception as e:
                        await ctx.send(f"Failed to validate emoji {trigger}: {str(e)}")
                        return

            self.event_counter += 1
            event_id = self.event_counter

            event_data = {
                'title': title,
                'time': utc_time,
                'description': description,
                'creator': ctx.author.id,
                'participants': set(),
                'maybe': set(),
                'declined': set(),
                'custom_triggers': custom_trigger_dict,
                'message_id': None,
                'channel_id': ctx.channel.id,
                'timezone': timezone
            }

            # Create and send event embed
            embed = await self.create_event_embed(event_data, event_id)
            message = await ctx.send(embed=embed)

            # Add reactions for RSVPs
            await message.add_reaction('✅')  # Going
            await message.add_reaction('❔')  # Maybe
            await message.add_reaction('❌')  # Not Going

            # Add custom activity reactions
            if custom_trigger_dict:
                for trigger in custom_trigger_dict.keys():
                    await message.add_reaction(trigger)

            event_data['message_id'] = message.id
            self.events[event_id] = event_data

            # Start the event tracking
            self.setup_reminder(event_id)

        except Exception as e:
            await ctx.send(f"An error occurred: {str(e)}")

    async def create_event_embed(self, event_data, event_id):
        """Create an embed for the event"""
        # Convert event time to various common timezones for display
        common_timezones = {
            'IST': 'Asia/Kolkata',
            'UTC': 'UTC',
            'ET': 'US/Eastern',
            'PT': 'US/Pacific'
        }

        time_displays = []
        utc_time = event_data['time']

        for tz_name, tz_id in common_timezones.items():
            local_time = utc_time.astimezone(pytz.timezone(tz_id))
            time_displays.append(f"{tz_name}: {local_time.strftime('%I:%M %p')}")

        now = datetime.now(pytz.UTC)
        time_remaining = event_data['time'] - now

        # Create the main embed
        embed = discord.Embed(
            title=f"📅 Event: {event_data['title']}", 
            description=f"{event_data['description']}\n\n⏰ **Time Remaining: {self.format_time_remaining(time_remaining)}**",
            color=discord.Color.blue()
        )

        # Add date and timezone information
        embed.add_field(
            name="📆 Date & Time",
            value=(
                f"**Date:** {utc_time.strftime('%A, %B %d, %Y')}\n"
                + "\n".join([f"**{display}**" for display in time_displays])
            ),
            inline=False
        )

        # Display RSVP counts in a single line
        rsvp_counts = (
            f"✅ **Going:** {len(event_data['participants'])} | "
            f"❔ **Maybe:** {len(event_data['maybe'])} | "
            f"❌ **Not Going:** {len(event_data['declined'])}"
        )
        embed.add_field(name="📊 RSVP Status", value=rsvp_counts, inline=False)

        # Display activity groups with their participants (optimized for up to 10 groups)
        if event_data['custom_triggers']:
            embed.add_field(name="🎯 Activity Groups", value="React with an emoji to join a group:", inline=False)

            # Split activity groups into rows of 2 for better formatting
            trigger_items = list(event_data['custom_triggers'].items())
            for i in range(0, len(trigger_items), 2):
                current_row = trigger_items[i:i+2]
                for trigger, users in current_row:
                    if users:
                        trigger_users = [f"<@{user_id}>" for user_id in users]
                        embed.add_field(
                            name=f"{trigger} Group ({len(users)})",
                            value="\n".join(trigger_users[:5]) + (f"\n*+{len(trigger_users)-5} more*" if len(trigger_users) > 5 else ""),
                            inline=True
                        )
                    else:
                        embed.add_field(
                            name=f"{trigger} Group",
                            value="No participants yet",
                            inline=True
                        )

                # Add empty field for alignment if odd number of groups in current row
                if len(current_row) % 2 == 1:
                    embed.add_field(name="\u200b", value="\u200b", inline=True)

        # Add other fields (participants, maybe, etc.) as before...
        if event_data['participants']:
            participants = [f"<@{user_id}>" for user_id in event_data['participants']]
            embed.add_field(
                name="✅ Confirmed Participants",
                value="\n".join(participants) if len(participants) <= 10 else f"**{len(participants)} members**",
                inline=False
            )

        # Show maybe participants
        if event_data['maybe']:
            maybe = [f"<@{user_id}>" for user_id in event_data['maybe']]
            embed.add_field(
                name="❔ Maybe Attending",
                value="\n".join(maybe) if len(maybe) <= 5 else f"**{len(maybe)} members**",
                inline=False
            )

        creator = self.bot.get_user(event_data['creator'])
        embed.set_footer(text=f"Event ID: {event_id} | Created by: {creator.name if creator else 'Unknown'}")

        return embed

    async def handle_event_end(self, event_id):
        """Handle event completion"""
        event = self.events[event_id]
        channel = self.bot.get_channel(event['channel_id'])
        if channel:
            try:
                message = await channel.fetch_message(event['message_id'])
                embed = discord.Embed(
                    title=f"🎉 Event Completed: {event['title']}",
                    description=event['description'],
                    color=discord.Color.gold()
                )

                # Add final attendance information for standard RSVPs
                participants = [f"<@{user_id}>" for user_id in event['participants']]
                maybe = [f"<@{user_id}>" for user_id in event['maybe']]
                declined = [f"<@{user_id}>" for user_id in event['declined']]

                if participants:
                    embed.add_field(
                        name=f"✅ Final Attendance ({len(participants)})",
                        value="\n".join(participants) if len(participants) <= 10 else f"{len(participants)} members",
                        inline=False
                    )

                # Add final custom trigger counts
                for trigger, users in event['custom_triggers'].items():
                    if users:
                        trigger_users = [f"<@{user_id}>" for user_id in users]
                        embed.add_field(
                            name=f"{trigger} Final Participants ({len(users)})",
                            value="\n".join(trigger_users) if len(trigger_users) <= 5 else f"{len(trigger_users)} members",
                            inline=False
                        )

                embed.set_footer(text="Event has ended | Thank you for participating!")
                await message.edit(embed=embed)

                # Send completion notification
                await channel.send(f"🎉 Event '{event['title']}' has ended! Thank you to all participants!")

            except discord.NotFound:
                pass

        # Cleanup
        del self.events[event_id]
        if event_id in self.reminder_tasks:
            self.reminder_tasks[event_id].cancel()
            del self.reminder_tasks[event_id]

    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        if user.bot:
            return

        message = reaction.message
        for event_id, event in self.events.items():
            if event['message_id'] == message.id:
                emoji = str(reaction.emoji)

                # Remove user from all standard lists first
                event['participants'].discard(user.id)
                event['maybe'].discard(user.id)
                event['declined'].discard(user.id)

                # Add to appropriate list
                if emoji == '✅':
                    event['participants'].add(user.id)
                elif emoji == '❔':
                    event['maybe'].add(user.id)
                elif emoji == '❌':
                    event['declined'].add(user.id)
                elif emoji in event['custom_triggers']:
                    # Add to both custom trigger group and confirmed participants
                    event['custom_triggers'][emoji].add(user.id)
                    event['participants'].add(user.id)  # Auto-confirm when joining activity group

                # Update the event message
                embed = await self.create_event_embed(event, event_id)
                await message.edit(embed=embed)
                break

    @commands.Cog.listener()
    async def on_reaction_remove(self, reaction, user):
        if user.bot:
            return

        message = reaction.message
        for event_id, event in self.events.items():
            if event['message_id'] == message.id:
                emoji = str(reaction.emoji)

                if emoji == '✅':
                    event['participants'].discard(user.id)
                elif emoji == '❔':
                    event['maybe'].discard(user.id)
                elif emoji == '❌':
                    event['declined'].discard(user.id)
                elif emoji in event['custom_triggers']:
                    event['custom_triggers'][emoji].discard(user.id)
                    # Only remove from participants if user is not in any other activity groups
                    in_other_groups = False
                    for trigger, users in event['custom_triggers'].items():
                        if trigger != emoji and user.id in users:
                            in_other_groups = True
                            break
                    if not in_other_groups:
                        event['participants'].discard(user.id)

                # Update the event message
                embed = await self.create_event_embed(event, event_id)
                await message.edit(embed=embed)
                break

    def setup_reminder(self, event_id):
        """Set up reminders for an event"""
        event = self.events[event_id]
        now = datetime.now(pytz.UTC)
        time_until_event = (event['time'] - now).total_seconds()

        # Cancel existing reminder if any
        if event_id in self.reminder_tasks:
            self.reminder_tasks[event_id].cancel()

        # Set up new reminder tasks
        if time_until_event > 0:
            task = asyncio.create_task(self.send_reminders(event_id, time_until_event))
            self.reminder_tasks[event_id] = task

    async def send_reminders(self, event_id, delay):
        """Send reminders at multiple intervals"""
        # Start-time reminders
        reminder_times = [
            (24 * 3600, "24 hours"),
            (3600, "1 hour"),
            (900, "15 minutes"),
            (300, "5 minutes"),
            (60, "1 minute")
        ]

        event = self.events[event_id]
        event_duration = (event['time'] - datetime.now(pytz.UTC)).total_seconds()

        # Add end-time reminders (30 min, 15 min, 5 min before end)
        end_reminder_times = [
            (1800, "30 minutes"),
            (900, "15 minutes"),
            (300, "5 minutes")
        ]

        # Handle start-time reminders
        for seconds, time_text in reminder_times:
            if delay > seconds:
                await asyncio.sleep(delay - seconds)
                if event_id not in self.events:
                    return

                event = self.events[event_id]
                channel = self.bot.get_channel(event['channel_id'])

                if channel:
                    mentions = ' '.join(f"<@{user_id}>" for user_id in event['participants'])
                    reminder_message = (
                        f"🔔 Reminder: Event '{event['title']}' starts in {time_text}!\n"
                        f"{mentions if mentions else 'No participants yet'}"
                    )
                    await channel.send(reminder_message)

                delay = seconds

        # Handle end-time reminders
        for seconds, time_text in end_reminder_times:
            end_delay = event_duration - seconds
            if end_delay > 0:
                await asyncio.sleep(end_delay)
                if event_id not in self.events:
                    return

                event = self.events[event_id]
                channel = self.bot.get_channel(event['channel_id'])

                if channel and event['participants']:
                    mentions = ' '.join(f"<@{user_id}>" for user_id in event['participants'])
                    reminder_message = (
                        f"⚠️ Alert: Event '{event['title']}' ends in {time_text}!\n"
                        f"{mentions}"
                    )
                    await channel.send(reminder_message)

    @commands.hybrid_command(
        name="eventinfo",
        description="View detailed information about a specific event"
    )
    @discord.app_commands.describe(
        event_id="The ID number of the event you want to view"
    )
    async def eventinfo(
        self,
        ctx: discord.Interaction,
        event_id: int
    ):
        """View detailed information about a specific event."""
        await log_command(ctx, "eventinfo")
        if event_id not in self.events:
            await ctx.response.send_message("Event not found!", ephemeral=True)
            return

        event = self.events[event_id]
        embed = await self.create_event_embed(event, event_id)

        await ctx.response.send_message(embed=embed)

    def format_time_remaining(self, time_delta):
        """Format timedelta into human readable string"""
        if time_delta.total_seconds() <= 0:
            return "Event has ended!"

        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        parts = []
        if days > 0:
            parts.append(f"{days} day{'s' if days != 1 else ''}")
        if hours > 0:
            parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        if seconds > 0 and not parts:  # Only show seconds if less than a minute
            parts.append(f"{seconds} second{'s' if seconds != 1 else ''}")

        if not parts:
            return "Starting now!"

        return ", ".join(parts)

    async def start_update_loop(self):
        """Start the update loop for all events"""
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                now = datetime.now(pytz.UTC)
                for event_id, event in list(self.events.items()):
                    if event['time'] > now:
                        channel = self.bot.get_channel(event['channel_id'])
                        if channel and event['message_id']:
                            try:
                                message = await channel.fetch_message(event['message_id'])
                                embed = await self.create_event_embed(event, event_id)
                                await message.edit(embed=embed)
                            except discord.NotFound:
                                continue
                    else:
                        await self.handle_event_end(event_id)
            except Exception as e:
                print(f"Error in update loop: {e}")
            await asyncio.sleep(30)  # Update every 30 seconds to avoid rate limiting


async def setup(bot):
    await bot.add_cog(Events(bot))