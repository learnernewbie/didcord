import discord
from discord.ext import commands
import operator
from utils.logger import log_command

class Calculator(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ops = {
            '+': operator.add,
            '-': operator.sub,
            '*': operator.mul,
            '/': operator.truediv,
            '**': operator.pow,
        }

    @commands.hybrid_command(
        name="calc",
        description="Perform basic calculations (+, -, *, /, **)"
    )
    @discord.app_commands.describe(
        expression="Math expression to calculate (e.g., '2 + 2' or '5 * 3')"
    )
    async def calc(self, ctx: commands.Context, *, expression: str):
        """
        Perform basic calculations (+, -, *, /, **)
        Example: /calc 2 + 2
        """
        await log_command(ctx, "calc")
        
        try:
            # Remove spaces and split the expression
            parts = expression.replace(' ', '').replace('÷', '/').replace('×', '*')
            
            # Check for power operator first
            if '**' in parts:
                num1, num2 = map(float, parts.split('**'))
                result = self.ops['**'](num1, num2)
            else:
                # Find the operator
                op = next((op for op in ['+', '-', '*', '/'] if op in parts), None)
                if not op:
                    raise ValueError("Invalid operator. Use +, -, *, /, or **")
                
                # Split numbers by operator and convert to float
                num1, num2 = map(float, parts.split(op))
                
                # Calculate result
                if op == '/' and num2 == 0:
                    raise ZeroDivisionError("Cannot divide by zero!")
                    
                result = self.ops[op](num1, num2)
            
            # Format result to remove trailing zeros if whole number
            if result.is_integer():
                result = int(result)
            
            embed = discord.Embed(
                title="Calculator Result",
                description=f"```\n{expression} = {result}\n```",
                color=discord.Color.blue()
            )
            
            if isinstance(ctx, discord.Interaction):
                await ctx.response.send_message(embed=embed)
            else:
                await ctx.send(embed=embed)
                
        except ZeroDivisionError as e:
            error_msg = str(e)
            if isinstance(ctx, discord.Interaction):
                await ctx.response.send_message(f"Error: {error_msg}", ephemeral=True)
            else:
                await ctx.send(f"Error: {error_msg}")
        except Exception as e:
            error_msg = "Invalid expression. Use format: number operator number (e.g., 2 + 2)"
            if isinstance(ctx, discord.Interaction):
                await ctx.response.send_message(error_msg, ephemeral=True)
            else:
                await ctx.send(error_msg)

async def setup(bot):
    await bot.add_cog(Calculator(bot))
